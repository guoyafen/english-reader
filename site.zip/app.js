'use strict';
const $=id=>document.getElementById(id);
const audio=$('speechAudio');
let books=[],book,pageIndex=0,selected=0,zoom=1,sequence=0,playing=false,finishAudio,selectedWord;
let db,recorder,micStream,micPending=false,recordTimer,recordUrl,recordingTarget;
const normalize=s=>s.toLowerCase().replace(/’/g,"'");
const page=()=>book.pages[pageIndex];
const block=()=>page().blocks[selected];
function toast(text){$('toast').textContent=text;$('toast').hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').hidden=true,6000);}
function status(text){$('status').textContent=text;}
function remember(key,value){try{localStorage.setItem('english-desk-v1-'+key,value);}catch(e){}}
function recall(key){try{return localStorage.getItem('english-desk-v1-'+key);}catch(e){return null;}}
function canNavigate(){if(micPending||recorder?.state==='recording'){toast('请先停止录音，再切换句子或页面。');return false;}return true;}
function stop(message){sequence++;audio.pause();if(finishAudio)finishAudio(false);audio.removeAttribute('src');playing=false;$('playAll').textContent='▶';$('playAll').setAttribute('aria-label','播放本页');document.querySelectorAll('.segment.reading').forEach(n=>n.classList.remove('reading'));if(message)status(message);}
async function playFile(src,token,text){
 if(token!==sequence)return false;
 return new Promise(resolve=>{
  let done=false;
  const end=ok=>{if(done)return;done=true;clearTimeout(timer);audio.onended=null;audio.onerror=null;audio.onplaying=null;audio.onwaiting=null;if(finishAudio===end)finishAudio=null;resolve(ok);};
  let timer=setTimeout(()=>{if(token===sequence){toast('音频加载较慢，请检查网络后重试。');status('音频未能加载');audio.pause();}end(false);},30000);
  finishAudio=end;audio.onended=()=>end(true);
  audio.onerror=()=>{if(token===sequence){toast('这段声音未能加载，请稍后重试。');status('声音暂时不可用');}end(false);};
  audio.onplaying=()=>{clearTimeout(timer);status('正在朗读 · '+text);};
  audio.onwaiting=()=>{status('正在加载声音…');clearTimeout(timer);timer=setTimeout(()=>{audio.pause();status('加载超时，请重试');end(false);},30000);};
  audio.src=src;audio.playbackRate=Number($('speed').value);audio.preservesPitch=true;status('正在加载声音…');
  audio.play().catch(()=>{if(token===sequence){status('请再点一次播放');toast('浏览器暂未播放音频，请再点“听这一句”。');}end(false);});
 });
}
async function listen(src=block().audio,text=block().text){
 if(!canNavigate())return;stop();$('recordingAudio').pause();const token=sequence;
 if(await playFile(src,token,text)&&token===sequence)status('听完啦，轮到你读一遍');
}
async function playPage(){
 if(!canNavigate())return;if(playing){stop('已停止');return;}
 stop();$('recordingAudio').pause();const token=sequence;playing=true;$('playAll').textContent='■';$('playAll').setAttribute('aria-label','停止本页播放');
 const sourcePage=page();let completed=true;
 for(let i=0;i<sourcePage.blocks.length;i++){
  if(token!==sequence)return;const b=sourcePage.blocks[i];if(b.kind==='instruction')continue;
  selected=i;renderSelection();
  const repeat=$('mode').value==='repeat';const tracks=repeat?b.partAudio:[b.audio];const texts=repeat?b.parts:[b.text];
  for(let j=0;j<tracks.length;j++){
   document.querySelectorAll('.segment').forEach((el,k)=>el.classList.toggle('reading',repeat&&k===j));
   if(!await playFile(tracks[j],token,texts[j])||token!==sequence){completed=false;break;}
   if(repeat)for(let left=Number($('gap').value);left>0;left--){if(token!==sequence)return;status(`轮到你读啦 · 还有 ${left} 秒`);await new Promise(r=>setTimeout(r,1000));}
  }
  if(!completed)break;
 }
 if(token===sequence){playing=false;$('playAll').textContent='▶';$('playAll').setAttribute('aria-label','播放本页');document.querySelectorAll('.segment.reading').forEach(n=>n.classList.remove('reading'));if(completed)status('这一页读完啦，真不错！');}
}
function setZoom(value){zoom=Math.max(1,Math.min(2.5,value));$('imageStage').style.width=zoom*100+'%';$('zoomLabel').textContent=Math.round(zoom*100)+'%';$('zoomOut').disabled=zoom===1;$('zoomIn').disabled=zoom===2.5;}
function renderLibrary(){
 $('library').replaceChildren();$('pagePicker').replaceChildren();
 book.pages.forEach((p,i)=>{
  const option=document.createElement('option');option.value=i;option.textContent=`第 ${p.readerPage} 页 · 书内 ${p.printedPage}`;$('pagePicker').append(option);
  const button=document.createElement('button');button.className='library-item';button.setAttribute('aria-label',`阅读器第${p.readerPage}页：${p.title}`);
  const img=document.createElement('img');img.src=p.image;img.alt='';img.loading='lazy';
  const label=document.createElement('span'),title=document.createElement('strong'),sub=document.createElement('small');title.textContent=p.title;sub.textContent=`第 ${p.readerPage} 页 · 书内 ${p.printedPage}`;label.append(title,sub);button.append(img,label);
  button.onclick=()=>{if(canNavigate())selectPage(i);};$('library').append(button);
 });
}
function selectBook(id){
 book=books.find(b=>b.id===id)||books[0];$('bookPicker').value=book.id;$('bookTitle').textContent=book.title;$('edition').textContent=book.edition;$('unit').textContent=book.unit;document.title=`课本开口说 · ${book.title}`;
 remember('book',book.id);renderLibrary();let index=Number(recall('page-'+book.id));if(!Number.isInteger(index)||index<0||index>=book.pages.length)index=0;selectPage(index);
}
function selectPage(index){
 stop();$('recordingAudio').pause();pageIndex=index;selected=0;$('lessonPanel').classList.remove('panel-open');
 const p=page();$('pageImage').src=p.image;$('pageImage').alt=`${book.edition}${book.title}，阅读器第${p.readerPage}页，书内第${p.printedPage}页：${p.title}`;
 $('pageTitle').textContent=p.title;$('section').textContent=p.section;$('pagePicker').value=index;$('pagePrev').disabled=index===0;$('pageNext').disabled=index===book.pages.length-1;
 $('pageMeta').textContent=`阅读器 ${p.readerPage} · 书内 ${p.printedPage} · ${p.blocks.length} 个点读区`;$('pageTip').textContent=p.tip;
 $('notice').textContent=p.readerPage===12?'本页的字母按钮读字母名称，单词按钮读整词。听力题未附原录音，暂不提供原题答案。':p.readerPage===14?'歌谣提供文字朗读，可以跟着节拍自己练习。':'点读时，右侧句子卡会显示更大的英文。手机上可用“查看句子”打开句子卡。';
 [...$('library').children].forEach((el,i)=>{el.classList.toggle('active',i===index);el.setAttribute('aria-current',i===index?'page':'false');});
 $('hotspots').replaceChildren();$('sentenceList').replaceChildren();
 p.blocks.forEach((b,i)=>{
  const hit=document.createElement('button');hit.className='hotspot';hit.setAttribute('aria-label','点读：'+b.text);hit.title=b.text;const [x,y,w,h]=b.box;Object.assign(hit.style,{left:x*100+'%',top:y*100+'%',width:w*100+'%',height:h*100+'%'});hit.onclick=()=>choose(i,true);$('hotspots').append(hit);
  const row=document.createElement('button');row.textContent=b.text;row.onclick=()=>choose(i,true);$('sentenceList').append(row);
 });
 $('regionCount').textContent=p.blocks.length+' 条';setZoom(1);$('imageViewport').scrollLeft=0;remember('page-'+book.id,index);renderSelection();status('准备好了，点一句试试看');
}
function choose(index,shouldPlay=false){if(!canNavigate())return;stop();selected=index;renderSelection();$('lessonPanel').classList.add('panel-open');if(shouldPlay)listen();else status('点“听这一句”播放');}
function renderSelection(){
 const b=block();$('wordCard').hidden=true;selectedWord=null;$('english').replaceChildren();
 [...$('hotspots').children].forEach((el,i)=>el.classList.toggle('active',i===selected));[...$('sentenceList').children].forEach((el,i)=>el.classList.toggle('active',i===selected));
 $('sentenceIndex').textContent=`${selected+1} / ${page().blocks.length}`;$('kind').textContent={instruction:'题目与说明',sentence:'课文听读',word:'单词与名字',letter:'字母名称'}[b.kind];
 const displayed=b.kind==='letter'?[b.text]:b.parts;
 for(const [i,part] of displayed.entries()){
  const span=document.createElement('span');span.className='segment';
  if(b.kind==='letter')span.textContent=part;
  else for(const token of part.match(/[A-Za-z]+(?:['’][A-Za-z]+)*|[^A-Za-z]+/g)||[]){
   const entry=book.words[normalize(token)];
   if(entry){const btn=document.createElement('button');btn.className='word';btn.textContent=token;btn.title='查看 '+token+' 的意思';btn.onclick=()=>showWord(entry);span.append(btn);}else span.append(document.createTextNode(token));
  }
  $('english').append(span);if(i<displayed.length-1)$('english').append(document.createTextNode(' '));
 }
 $('translation').textContent=b.zh;$('explanation').textContent=b.note;$('wordHint').textContent=b.kind==='letter'?'大写和小写是一对，点“听这一句”听字母名称':'点上面的英文单词，查词、听发音';
 $('previous').disabled=selected===0;$('next').disabled=selected===page().blocks.length-1;$('recordingStatus').textContent='';$('record').innerHTML='<i></i> 开始录音';loadRecording();
}
function showWord(entry){selectedWord=entry;$('wordTitle').textContent=entry.text;$('wordMeaning').textContent=entry.zh;$('wordCard').hidden=false;}
function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open('english-desk-v1',1);r.onupgradeneeded=()=>r.result.createObjectStore('recordings');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
function recordingKey(){return `${book.id}:${page().id}:${block().id}`;}
function getRecording(key){if(!db)return Promise.resolve(null);return new Promise((resolve,reject)=>{const r=db.transaction('recordings').objectStore('recordings').get(key);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
function saveRecording(key,value){if(!db)return Promise.reject(new Error('No local storage'));return new Promise((resolve,reject)=>{const t=db.transaction('recordings','readwrite');t.objectStore('recordings').put(value,key);t.oncomplete=resolve;t.onerror=t.onabort=()=>reject(t.error);});}
function showRecording(record){if(recordUrl)URL.revokeObjectURL(recordUrl);recordUrl=URL.createObjectURL(record.blob);$('recordingAudio').src=recordUrl;$('downloadRecording').href=recordUrl;$('downloadRecording').download=`英语跟读-${page().readerPage}-${selected+1}.${record.type.includes('mp4')?'m4a':'webm'}`;$('recordingBox').hidden=false;}
async function loadRecording(){
 $('recordingAudio').pause();$('recordingAudio').removeAttribute('src');$('recordingBox').hidden=true;if(recordUrl){URL.revokeObjectURL(recordUrl);recordUrl=null;}
 const key=recordingKey();try{const record=await getRecording(key);if(record&&key===recordingKey())showRecording(record);}catch(e){}
}
function stopMic(){clearInterval(recordTimer);micStream?.getTracks().forEach(t=>t.stop());micStream=null;$('record').classList.remove('recording');}
async function toggleRecord(){
 if(recorder?.state==='recording'){recorder.stop();return;}if(micPending)return;
 if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){toast('当前浏览器无法录音。请在 HTTPS 网站上用系统浏览器或 Chrome 打开；仍然可以听示范、自由跟读。');return;}
 stop('准备录音');$('recordingAudio').pause();micPending=true;$('record').disabled=true;
 try{
  micStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:false});
  const type=['audio/webm;codecs=opus','audio/mp4','audio/webm'].find(t=>MediaRecorder.isTypeSupported(t));
  recorder=new MediaRecorder(micStream,type?{mimeType:type}:undefined);const current=recorder,target=recordingKey(),parts=[];let failed=false;recordingTarget=target;
  current.ondataavailable=e=>{if(e.data.size)parts.push(e.data);};
  current.onerror=()=>{failed=true;stopMic();toast('录音中断，请重新试一次。');$('record').innerHTML='<i></i> 重新录音';};
  current.onstop=async()=>{
   stopMic();$('record').innerHTML='<i></i> 再录一次';if(failed||!parts.length)return;
   const record={blob:new Blob(parts,{type:current.mimeType}),type:current.mimeType,createdAt:Date.now()};let saved=true;
   try{await saveRecording(target,record);}catch(e){saved=false;}
   if(target===recordingKey()&&recorder.state!=='recording'){showRecording(record);$('recordingStatus').textContent=saved?'录好了，听听自己的声音吧。':'录好了，未能存入浏览器，请下载保留。';status('录音完成，可以对照示范听一听');}
  };
  current.start();const started=Date.now();$('record').classList.add('recording');$('record').innerHTML='<i></i> 停止录音';$('recordingBox').hidden=true;status('正在录音，读完点“停止录音”');
  recordTimer=setInterval(()=>{const seconds=Math.floor((Date.now()-started)/1000);$('recordingStatus').textContent=`录音中 ${seconds} 秒 · 仅保存在当前浏览器`;if(seconds>=120&&current.state==='recording')current.stop();},250);
 }catch(e){stopMic();toast('没有开始录音。请允许麦克风权限后重试，也可以直接跟着示范读。');status('未开始录音');}
 finally{micPending=false;$('record').disabled=false;}
}
function bind(){
 $('listen').onclick=()=>listen();$('playAll').onclick=playPage;$('stop').onclick=()=>stop('已停止');
 $('wordSpeak').onclick=()=>{if(selectedWord)listen(selectedWord.audio,selectedWord.text);};$('wordClose').onclick=()=>$('wordCard').hidden=true;
 $('previous').onclick=()=>choose(Math.max(0,selected-1));$('next').onclick=()=>choose(Math.min(page().blocks.length-1,selected+1));
 $('pagePrev').onclick=()=>{if(canNavigate())selectPage(Math.max(0,pageIndex-1));};$('pageNext').onclick=()=>{if(canNavigate())selectPage(Math.min(book.pages.length-1,pageIndex+1));};
 $('pagePicker').onchange=()=>{if(canNavigate())selectPage(Number($('pagePicker').value));else $('pagePicker').value=pageIndex;};
 $('bookPicker').onchange=()=>{if(canNavigate())selectBook($('bookPicker').value);else $('bookPicker').value=book.id;};
 $('zoomIn').onclick=()=>setZoom(zoom+.25);$('zoomOut').onclick=()=>setZoom(zoom-.25);$('showAreas').onchange=()=>$('hotspots').classList.toggle('hide-areas',!$('showAreas').checked);
 $('toggleChinese').onclick=()=>{const hidden=!$('chineseArea').hidden;$('chineseArea').hidden=hidden;$('toggleChinese').setAttribute('aria-expanded',!hidden);$('toggleChinese').lastElementChild.textContent=hidden?'⌄':'⌃';};
 $('mode').onchange=()=>{stop('模式已更改');$('playTitle').textContent=$('mode').value==='repeat'?'一起逐句跟读':'听完整页';remember('mode',$('mode').value);};
 $('speed').onchange=()=>{audio.playbackRate=Number($('speed').value);remember('speed',$('speed').value);};$('gap').onchange=()=>remember('gap',$('gap').value);
 $('record').onclick=toggleRecord;$('recordingAudio').onplay=()=>stop('正在听自己的录音');
 $('openPanel').onclick=()=>$('lessonPanel').classList.toggle('panel-open');$('closePanel').onclick=()=>$('lessonPanel').classList.remove('panel-open');$('help').onclick=()=>$('helpDialog').showModal();
 $('pageImage').onerror=()=>toast('课本图片未加载，请检查网络后刷新。');
 window.addEventListener('beforeunload',e=>{if(recorder?.state==='recording'){e.preventDefault();e.returnValue='';}});
 window.addEventListener('pagehide',()=>{stop();stopMic();});
 document.addEventListener('keydown',e=>{if(['INPUT','SELECT','TEXTAREA','BUTTON'].includes(document.activeElement.tagName)||document.querySelector('dialog[open]'))return;if(e.key==='ArrowLeft'&&pageIndex>0&&canNavigate())selectPage(pageIndex-1);if(e.key==='ArrowRight'&&pageIndex<book.pages.length-1&&canNavigate())selectPage(pageIndex+1);if(e.key==='Escape')$('lessonPanel').classList.remove('panel-open');});
}
async function init(){
 $('reload').onclick=()=>location.reload();
 try{
  const response=await fetch('books.json',{cache:'no-cache'});if(!response.ok)throw new Error();const data=await response.json();books=data.books;if(!books?.length)throw new Error();
  try{db=await openDB();}catch(e){toast('浏览器存储不可用，学习功能仍可用；录音请下载保留。');}
  for(const b of books){const o=document.createElement('option');o.value=b.id;o.textContent=b.title;$('bookPicker').append(o);}$('bookPickerLabel').hidden=books.length<2;
  for(const id of ['mode','speed','gap']){const value=recall(id);if([...$(id).options].some(o=>o.value===value))$(id).value=value;}
  bind();selectBook(recall('book'));$('playTitle').textContent=$('mode').value==='repeat'?'一起逐句跟读':'听完整页';$('loading').hidden=true;$('app').hidden=false;
 }catch(e){$('loadMessage').textContent='课本暂时没有加载成功，请检查网络后重新打开。';$('reload').hidden=false;}
}
init();
